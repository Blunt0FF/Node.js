
import './App.css'
import Form from './Components/Form/Form'

function App() {

  return (
    <>
      <Form/>
    </>
  )
}

export default App
