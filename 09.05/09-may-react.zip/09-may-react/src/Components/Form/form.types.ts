export interface IForm {

}

export interface ILoginForm {
    username: string
    password: string
    email?: string
}