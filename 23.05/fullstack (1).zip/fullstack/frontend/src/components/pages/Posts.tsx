function Posts() {
return (
        <div>
            posts
        </div>
    )
}

export default Posts