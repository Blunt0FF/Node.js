1. npm init -y
2. npm i ts-node typescript nodemon -D
`typescript`: Сам компилятор TypeScript, который переводит TypeScript код в JavaScript.
`ts-node`: Инструмент, который позволяет запускать TypeScript код напрямую без необходимости предварительной компиляции в JavaScript.
3. npx tsc --init

npx tsc ./src/index.ts - данная команда компилирует ts в JS код