npm init -y

Помимо всех классических шагов, что у нас были перечисленные в README.md для начала работы с сервером, мы устанавливаем глобально тс
npm i -g typescript     
npm i -g ts-node 

npm i -D @types/express
npx tsc --init


npm i express dotenv mongoose mongodb
npm install -D typescript ts-node @types/node @types/express @types/mongoose

