import { Router } from "express";
import { addNewTask, deleteTask, getAllTasks, updateTask } from "../controllers/taskController";


const router = Router()

router.get('/', getAllTasks)
router.post('/', addNewTask)
router.put('/:id', updateTask)
router.delete('/:id', deleteTask)


export default router