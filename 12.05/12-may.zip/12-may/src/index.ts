//в параметр функции можно установить сразу начальное значение параметра
function multiply(a: number, b: number = 10): number {
  if (b && a > b) {
    return a * b;
  }
  return a;
}

multiply(5);

const multiplyArrow = (a: number, b: number): number => {
  const tempResult = a > b ? a * b : a / b;
  return tempResult;
};
//     {
//     return a * b
// }

// T, G - обобщенный тип (generic) смысл которого принять любой тип данных в момент вызова функции
function identity<T, G>(value: T, num: G): T | G {
  if (typeof value === "string") {
    return value;
  }
  return num;
}

const res1 = identity<string, number>("hello world", 10);

function getFirstElem<T>(arr: T[]): T {
  return arr[0];
}

const arrRes1 = getFirstElem<number>([4, 3, 2, 5, 1, 9]);
const arrRes2 = getFirstElem<string>(["hello first string", "asdas", "asdasd"]);
console.log(arrRes2);

function generateObj<T, K extends keyof T>(obj: T, key: K): T[K] {
  return obj[key];
}

interface obj {
  id: number;
  str: string;
  data: number;
}

function fn5<T extends obj>(arr: T[]): string[] {
  return arr.map((item) => item.str);
}

console.log(fn5<obj>([{ id: 1, str: "hello", data: 2323 }, { id: 2, str: "hello2", data: 232343 }]));

interface Iobj {
    id: number,
    str: string
    data: number
}

function fn6<T extends Iobj>(arr:T[]): (string | number)[]{
    return arr.map(item => item.str)
}
const users: Iobj[] = [
    { id: 1, str: "Alex", data: 100 },
    { id: 2, str: "Alex1", data: 200 }
  ];
console.log(fn6(users));